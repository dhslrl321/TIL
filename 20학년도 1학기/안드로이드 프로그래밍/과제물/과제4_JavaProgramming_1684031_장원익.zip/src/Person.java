
/*Person 클래스 : Hero와 Support의 상위 클래스*/
public class Person {
    private String name;
    private int age;
    private String address;
    private String dept;
    private int sal;
    private int workTime;

    Person(String name, int age, String address, String dept){
        this.name = name;
        this.age = age;
        this.address = address;
        this.dept = dept;
    }

    void setSal(int sal){
        this.sal = sal;
    }

    int getSal(){
        return sal;
    }

    public void printInfo(){
        System.out.println(name);
        System.out.println(age);
        System.out.println(address);
        System.out.println(dept);
    }

    void setWorkTime(int workTime){
        this.workTime = workTime;
    }
}

class Hero extends Person{

    Hero(String name, int age, String address, String dept) {
        super(name, age, address, dept);
    }

    void setSal(int sal){
        super.setSal(sal);
    }

    public void printInfo(){
        System.out.println("정규직" + "월급 : " + super.getSal());
    }
}

class Support extends Person{

    private int workMoney = 12500;
    private int workTime = 0;

    Support(String name, int age, String address, String dept) {
        super(name, age, address, dept);
    }

    void setWorkTime(int workTime){
        this.workTime = workTime;
        super.setSal(workMoney * workTime);
    }


    public void printInfo(){
        System.out.println("비정규직 " + "월급 : " + super.getSal() + " 일한 시간 : " + workTime);
    }
}