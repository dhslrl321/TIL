public class 문제3번 {
    public static void main(String[] args) {
        Hero r = new Hero("홍길동", 36, "seoul", "총무");
        Support t = new Support("신짱구", 25, "대전", "경리부");

        r.setSal(4500000);
        r.printInfo();
        t.setWorkTime(117);
        t.printInfo();
    }
}
