class Circle:
    def __init__(self, center, radius):
        self.center = center
        self.radius = radius
