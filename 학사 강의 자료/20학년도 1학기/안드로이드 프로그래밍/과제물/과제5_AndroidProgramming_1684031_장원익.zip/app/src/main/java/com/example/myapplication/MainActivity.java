package com.example.myapplication;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    Button plusBtn, minusBtn, divBtn, multiBtn, nextActivity;
    TextView resultView;
    EditText operand1, operand2;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
        nextActivity = (Button) findViewById(R.id.nextActivity);
        plusBtn = (Button) findViewById(R.id.plusBtm);
        minusBtn = (Button) findViewById(R.id.minBtn);
        multiBtn = (Button) findViewById(R.id.multBtn);
        divBtn = (Button) findViewById(R.id.divBtn);

        operand1 = (EditText) findViewById(R.id.operand1);
        operand2 = (EditText) findViewById(R.id.operand2);

        resultView = (TextView) findViewById(R.id.resultText);

        plusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1 = Integer.parseInt(operand1.getText().toString());
                int num2 = Integer.parseInt(operand2.getText().toString());

                resultView.append(String.valueOf(num1+num2));
            }
        });

        minusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1 = Integer.parseInt(operand1.getText().toString());
                int num2 = Integer.parseInt(operand2.getText().toString());

                resultView.append(String.valueOf(num1-num2));
            }
        });
        multiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1 = Integer.parseInt(operand1.getText().toString());
                int num2 = Integer.parseInt(operand2.getText().toString());

                resultView.append(String.valueOf(num1*num2));
            }
        });
        divBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1 = Integer.parseInt(operand1.getText().toString());
                int num2 = Integer.parseInt(operand2.getText().toString());

                resultView.append(String.valueOf(num1/num2));
            }
        });

        nextActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setContentView(R.layout.animal);
            }
        });

    }

}
