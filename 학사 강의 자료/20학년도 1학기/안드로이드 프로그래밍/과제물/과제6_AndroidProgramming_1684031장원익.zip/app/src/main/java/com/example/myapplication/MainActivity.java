package com.example.myapplication;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    CheckBox startBox, exitBox;

    RadioGroup group;
    RadioButton catBtn, rabbitBtn, dogBtn;

    ImageView image;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);

        group = (RadioGroup) findViewById(R.id.radioGroup);
        startBox = (CheckBox) findViewById(R.id.startChk);
        dogBtn = (RadioButton) findViewById(R.id.rBtn1);
        catBtn = (RadioButton) findViewById(R.id.rBtn2);
        rabbitBtn = (RadioButton) findViewById(R.id.rBtn3);

        image = (ImageView) findViewById(R.id.image);


        startBox.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                group.setVisibility(View.VISIBLE);
                return false;
            }
        });

        dogBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image.setImageResource(R.drawable.dog);
            }
        });

        catBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image.setImageResource(R.drawable.cat);
            }
        });

        rabbitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image.setImageResource(R.drawable.rabbit);
            }
        });
    }

}
